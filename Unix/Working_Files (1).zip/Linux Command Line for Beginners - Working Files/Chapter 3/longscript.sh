#!/bin/sh

sleep 20
echo "All done!"
