#!/bin/sh

(while :
do
	expr 1 + 3 >/dev/null
done) &
